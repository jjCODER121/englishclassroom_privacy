English Classroom — GitHub Pages

1. Create a public GitHub repository called privacy-policy.
2. Upload index.html to its root directory.
3. Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Your public URL will be https://YOUR-USERNAME.github.io/privacy-policy/
5. Check it in a private browser and place it in Google Play Console and inside the app.

IMPORTANT: Check SDK behavior, data collection, ad consent and applicable children/families rules before publishing. The source policy states that internet is used only when the reward-ad button is clicked; Google Mobile Ads SDK may initialize/network before then, so verify the claim. GDPR-K/COPPA/Play compliance cannot be established just from policy text.
