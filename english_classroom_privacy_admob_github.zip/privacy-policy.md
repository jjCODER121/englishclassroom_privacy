# Политика конфиденциальности — English Classroom

*Дата вступления в силу: 29.09.2026*

English Classroom («приложение») — обучающая игра для детей для изучения английского
языка. Разработчик: ORIFSOFT, контакт: orifsoft@gmail.com.

## Коротко

* Приложение **не собирает, не передаёт и не продаёт** личные данные ребёнка и
  не требует регистрации или аккаунта.
* Все уроки, задания, озвучка и прогресс работают **полностью без интернета**.
* Интернет используется только в одном необязательном месте — экран альбома
  наклеек, кнопка «Наклейка за рекламу» (см. ниже, раздел «Реклама»).
* Микрофон используется только в упражнении «Повтори за мной»; запись **не сохраняется
  и никуда не отправляется**.

## Какие данные хранятся и где

Приложение хранит **только на устройстве**, во внутренней памяти приложения:

* прогресс обучения: пройденные уроки и модули, звёзды, результаты заданий;
* выученные слова и расписание их повторения;
* полученные наклейки и выбранный наряд питомца;
* даты занятий (для серии «дней подряд»);
* настройки: выбранный класс, направление перевода, включён ли звук.

Имя, возраст, e-mail, телефон, местоположение, фотографии, контакты и другие
персональные данные приложение **не запрашивает и не хранит**.

Эти данные недоступны разработчику и третьим лицам. Они удаляются вместе
с приложением или через «Настройки → Приложения → English Classroom → Хранилище →
Очистить данные».

## Микрофон

Разрешение на микрофон (RECORD_AUDIO) запрашивается только тогда, когда ребёнок
впервые нажимает кнопку «Повтори за мной». Приложение записывает несколько секунд
звука, сразу воспроизводит запись ребёнку и затем удаляет её из памяти. Записи
**не сохраняются в файлы и не анализируются для распознавания личности**. Без
разрешения на микрофон все остальные функции работают.

## Реклама

На экране альбома наклеек есть необязательная кнопка **«Наклейка за рекламу»**:
ребёнок сам решает, посмотреть ли короткий рекламный ролик, чтобы получить одну
дополнительную наклейку. Кнопка не появляется, пока ролик не готов, и её можно
просто не нажимать — все остальные наклейки открываются обычными успехами в
учёбе, без всякой рекламы.

Ролики показывает **Google AdMob**. Только в момент, когда ребёнок сам нажимает
эту кнопку, приложению нужен доступ в интернет и Google может получить
технические данные, необходимые для показа ролика (например, идентификатор
рекламы устройства, приблизительные технические параметры устройства и IP-адрес).
Реклама настроена как **предназначенная для детей**: без персонализации и
поведенческого таргетинга, только контент возрастной категории «для всех»
(Google Play Families Policy, COPPA, GDPR-K). Мы не получаем и не видим эти
данные сами — их обрабатывает только Google. Подробнее о том, как Google
обрабатывает данные в своих партнёрских сервисах:
https://policies.google.com/technologies/ads

## Дети

Приложение предназначено для детей. Мы не собираем персональные данные детей,
не содержим покупок внутри приложения и ссылок на внешние сайты. Единственная
реклама — описанные выше необязательные ролики за наклейку, настроенные без
персонализации специально для детской аудитории. Приложение соответствует
требованиям Google Play для семейных приложений (Families Policy), а также
принципам COPPA (США) и GDPR (ЕС) в части защиты данных детей.

## Изменения политики

При изменении политики новая версия будет опубликована по этому адресу с новой
датой вступления в силу.

## Контакты

Вопросы о конфиденциальности: orifsoft@gmail.com.

---

# Privacy Policy — English Classroom

*Effective date: 29.09.2026*

English Classroom (“the app”) is an educational game that helps children learn English.
Developer: ORIFSOFT, contact: orifsoft@gmail.com.

## Summary

* The app **does not collect, share or sell** the child’s personal data, and
  requires no sign-up or account.
* All lessons, exercises, voice-over and progress work **fully offline**.
* Internet access is used in exactly one optional place — the sticker album
  screen, “Get a sticker for watching an ad” button (see “Advertising” below).
* The microphone is used only in the “Repeat after me” exercise; recordings are
  **not stored and not sent anywhere**.

## What is stored and where

The app stores **only on the device**, in the app’s private storage: learning progress
(completed lessons and modules, stars, exercise results), learned words and their review
schedule, earned stickers and the pet’s outfit, days of practice (for the streak), and
settings (selected class, translation direction, sound on/off).

The app does **not** ask for or store names, age, e-mail, phone number, location, photos,
contacts or any other personal information. This data is not accessible to the developer
or any third party and is deleted when the app is uninstalled or its data is cleared.

## Microphone

The microphone permission (RECORD_AUDIO) is requested only when the child first taps
“Repeat after me”. The app records a few seconds of audio, plays it back to the child
immediately and then discards it from memory. Recordings are **never saved to files and
never used to identify anyone**. All other features work without this permission.

## Advertising

The sticker album screen has an optional **“Get a sticker for watching an ad”**
button: the child may choose to watch a short ad to receive one extra sticker.
The button only appears once an ad is ready, and it never has to be used — every
other sticker is earned through ordinary learning progress, with no ad involved.

Ads are served by **Google AdMob**. Only at the moment the child taps this
button does the app need internet access, and Google may receive the technical
data needed to serve an ad (for example, the device’s advertising identifier,
approximate device information and IP address). Ads are configured as
**child-directed**: no personalization or behavioral targeting, and content is
restricted to the “G” (general audience) rating (Google Play Families Policy,
COPPA, GDPR-K). We do not receive or see this data ourselves — only Google
processes it. More on how Google handles data through its partner services:
https://policies.google.com/technologies/ads

## Children

The app is designed for children. We do not collect personal information from
children, and have no in-app purchases or links to external websites. The only
advertising is the optional reward video described above, configured without
personalization specifically for a child audience. The app follows the Google
Play Families Policy and the principles of COPPA (US) and GDPR (EU) regarding
children’s data.

## Changes

If this policy changes, the new version will be published at this address with a new
effective date.

## Contact

Privacy questions: orifsoft@gmail.com.
